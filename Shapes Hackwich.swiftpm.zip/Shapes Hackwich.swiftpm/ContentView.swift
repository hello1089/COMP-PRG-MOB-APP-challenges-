/*
Aidan Neff

Shapes Hackwich
 
 September 3, 2024
*/ 
 
import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello")
            .frame(width: 100, height: 100, alignment: .center)
            .foregroundColor(.white)
            .background(Circle().fill(LinearGradient(colors: [.blue, .green], startPoint: .top, endPoint: .bottom)))
                 .foregroundColor(.red)
                 .background(.mint)
        Circle()
            .frame(width:100, height: 100, alignment: .center)
        Rectangle()
            .padding(50)
        Ellipse()
            .fill(.blue)
        RoundedRectangle(cornerRadius: 100.0)
            .fill(.orange)
            .opacity(0.8)
        Text("World!")
            .frame(width: 200, height: 100, alignment: .center)
            .foregroundColor(.cyan)
            .background(Capsule()
                .foregroundColor(.yellow)
                .background(.green)
            )
    }
}
