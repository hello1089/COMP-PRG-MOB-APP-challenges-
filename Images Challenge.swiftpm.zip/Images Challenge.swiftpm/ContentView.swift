/*
 Aidan Neff
 Images Challenge
 September 16, 2024
 */



import SwiftUI

struct ContentView: View {
    var body: some View {
        HStack {
        VStack {
            HStack {
                Text("N")
                    .foregroundColor(.black)
                    
            }
                    Image(systemName: "arrow.up")
                        .imageScale(.large)
            HStack {
                Text("W")
                    .frame( alignment: .leading)
                    .padding(.trailing, 0)   
                    
                Image(systemName: "arrow.left")
                    .frame(alignment: .center)
                    .padding(.trailing, 0)
                    .imageScale(.large)
                Image(systemName: "globe")
                    .frame(alignment: .center)
                    .padding(.trailing, 0)
                    .imageScale(.large)
                Image(systemName: "arrow.right")
                    .frame(alignment: .center)
                    .padding(.trailing, 0)
                    .imageScale(.large)
                Text("E")
                    .frame( alignment: .leading)
                    .padding(.trailing, 5.5)   
                    .imageScale(.large)
                
                } 
                Image(systemName: "arrow.down")
                .imageScale(.large)
                
                Text("S")
                .imageScale(.large)
                Image("sky_image_challenge")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .clipShape(Circle())
                    .frame(width: 200, height: 200)
                                            
            }
        }
    }
}
