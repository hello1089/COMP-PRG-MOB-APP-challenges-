/*
Aidan Neff
Shapes Stretches
Thursday, September 5
*/

import SwiftUI

struct ContentView: View {
    var body: some View {
        Rectangle()
            .frame(width: 100, height: 100)
            .foregroundColor(.blue)
            .border(Color.black, width: 10)
        
        Text("Click Me")
            .font(Font.custom("American Typewriter" , size: 35))
            .foregroundColor(.black)
            .frame(width: 300, height:50)
            .background(RoundedRectangle(cornerRadius: 10).fill(Color.blue))
    }
}
