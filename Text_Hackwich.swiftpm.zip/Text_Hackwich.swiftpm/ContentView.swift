import SwiftUI

struct ContentView: View {
    var body: some View {
        //   Text("Hello \nWorld")
        // \n after a space in Text("") to make the text appear on a new line without using Text("") again
        Text("Hello World")
            .foregroundColor(.red) //changed text color
            .background(Color(.white)) //changed background color
        Text("Mobile Apps is Fun!")
            .font(.largeTitle)
            .border(Color.black, width: /*@START_MENU_TOKEN@*/1/*@END_MENU_TOKEN@*/)
        .rotationEffect(Angle(degrees: 90.0)) //if it needs a double it needs a decimal number (example is 90.0)
    }
}


