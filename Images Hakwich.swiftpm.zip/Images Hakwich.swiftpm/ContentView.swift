import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundColor(.accentColor)
            //
            //
            Text("Hello, world!")
            //
            //
            Image(systemName: "book.closed.fill")
                .resizable()
                .frame(width: 100, height: 100, alignment: .center)
                .foregroundColor(.green)
                .background(LinearGradient(gradient: Gradient(colors: [Color.red, Color.blue, Color.teal, Color.cyan, Color.yellow]), startPoint: .topLeading, endPoint: .bottomTrailing))
            //
            //
            Image("dog")
                .resizable()
                .aspectRatio(contentMode: .fit) //keep the images original size
                .frame(width: 300, height: 300, alignment: .center)
                .background(LinearGradient(gradient: Gradient(colors: [Color.blue, Color.green]), startPoint: .topLeading, endPoint: .bottomTrailing))
            //
            //
            Image("globe")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .clipShape(Circle())
                .border(Color.black, width: 10)
            //
            //
            /*
             Image("dog")
             .resizable()
             .frame(width: 175, height: 125, alignment: .center)
             .rotation3DEffect(Angle(degrees: 295), axis: (x: 10.0, y: 10.0, z: 10.0))
             .padding(.all, 75)
             */
            
        }
        .background(.gray)
    }
}
