import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
           //MVP SECTION
            Text("Red")
                .foregroundColor(.red)
            Text("Blue")
                .background(.blue)
            Text("Big")
                .font(.system(size: 100))
            Text("Small")
                .font(.system(size: 8))
            Text("Left")
                .frame(maxWidth: .infinity , alignment: .leading)
            Text("Right")
                .frame(maxWidth: .infinity , alignment: .trailing)
            Text("Upside Down")
                .rotationEffect(Angle(degrees: 180))
            Spacer()
            //STRETCH SECTION
            Text("Cool Class")
                .font(Font.custom("Zapfino" , size: 25))
                .foregroundColor(.white)
                .background(.black)
            
            Spacer()
            Text("With Blue Border \n       Size 10 \nFrame 200 by 200")
                .frame(width: 200, height: 200)
                .foregroundColor(.black)
                .background(.yellow)
                .border(.blue, width: 10)
            Spacer()
    
            Text("😀")
                .font(Font.custom("Ariel", size: 100))
                .frame(width: 200, height: 100)
                .background(LinearGradient( gradient: Gradient(colors: [.white, .black]), startPoint: .top, endPoint: .bottom))
        
            
        }
    }
}
