//comments
//VStack(alignment: .leading, spacing: 30, content: {
//    Image(systemName: "globe")
//        .imageScale(.large)
//        .foregroundColor(.accentColor)
//        .background(.gray)
//    Text("Hello world!")
//        .background(.green)
//    //            Spacer()
//    //            Text("Another Text")
//    
//    
//    
//})
//.frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
//.background(LinearGradient(colors: [.black, .gray, .white, .blue, .cyan, .mint, .green, .white, .gray, .black], startPoint: .topLeading, endPoint: .bottomTrailing))
//.ignoresSafeArea()
