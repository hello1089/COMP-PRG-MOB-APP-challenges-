/*
 Stacks Hackwich
 Aidan Neff
 Monday, September 9th.
 */



import SwiftUI

struct ContentView: View {
    var body: some View {
//        VStack(alignment: .leading, spacing: 30, content: {
//            Image(systemName: "globe")
//                .imageScale(.large)
//                .foregroundColor(.accentColor)
//                .background(.gray)
//            Text("Hello world!")
//                .background(.green)
////            Spacer()
////            Text("Another Text")
//            
//            
//        
//        }
//        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
//        .background(LinearGradient(colors: [.black, .gray, .white, .blue, .cyan, .mint, .green, .white, .gray, .black], startPoint: .Leading, endPoint: .bottom)))
//        .ignoresSafeArea()
        
        
        ZStack {
            RoundedRectangle(cornerRadius: 80.0)
                .frame(width: 300, height: 300, alignment: .center)
            Circle()
                .frame(width:200, height: 200, alignment: .center)
                .foregroundColor(.accentColor)
            Rectangle()
                .frame(width: 100, height: 100, alignment: .center)
                                                        
            
            
            
            
            
            
        }
    }
}
