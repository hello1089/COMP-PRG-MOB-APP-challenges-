/*
 Stacks Challenge
 Aidan Neff
 Wensday, Sepember 11
 */

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Rectangle()
                .frame(width: 229, height: 150, alignment: .top)
                .foregroundColor(.gray)
                .opacity(0.15)
                .border(Color.black, width: 2)
            HStack {
                Text("1")
                    .frame(width: 50, height: 50, alignment: .center)
                    .border(Color.black, width: 1)
                Text("2")
                    .frame(width: 50, height: 50, alignment: .center)
                    .border(Color.black, width: 1)
                Text("3")
                    .frame(width: 50, height: 50, alignment: .center)
                    .border(Color.black, width: 1)
                Text("+")
                    .frame(width: 50, height: 50, alignment: .center)
                    .border(Color.black, width: 1)
            }
            HStack{ Text("4")
                    .frame(width: 50, height: 50, alignment: .center)
                    .border(Color.black, width: 1)
                Text("5")
                    .frame(width: 50, height: 50, alignment: .center)
                    .border(Color.black, width: 1)
                Text("6")
                    .frame(width: 50, height: 50, alignment: .center)
                    .border(Color.black, width: 1)
                Text("-")
                    .frame(width: 50, height: 50, alignment: .center)
                    .border(Color.black, width: 1)
            }
            HStack {
                Text("7")
                    .frame(width: 50, height: 50, alignment: .center)
                    .border(Color.black, width: 1)
                Text("8")
                    .frame(width: 50, height: 50, alignment: .center)
                    .border(Color.black, width: 1)
                Text("9")
                    .frame(width: 50, height: 50, alignment: .center)
                    .border(Color.black, width: 1)
                Text("*")
                    .frame(width: 50, height: 50, alignment: .center)
                    .border(Color.black, width: 1)
            }
            HStack {
                Text("/")
                    .frame(width: 50, height: 50, alignment: .center)
                    .border(Color.black, width: 1)
                Text("^")
                    .frame(width: 50, height: 50, alignment: .center)
                    .border(Color.black, width: 1)
                Text("=")
                    .frame(width: 50, height: 50, alignment: .center)
                    .border(Color.black, width: 1)
                Text(".")
                    .frame(width: 50, height: 50, alignment: .center)
                    .border(Color.black, width: 1)
            }
        }
        VStack {
            HStack {
                Text("Clear")
                    .frame(width: 100, height: 50, alignment: .center)
                    .border(Color.black)
                    .padding(.all, -3)
                Text("ans")
                    .frame(width: 50, height: 50, alignment: .center)
                    .border(Color.black, width: 1)
            }
        }
    }
}
