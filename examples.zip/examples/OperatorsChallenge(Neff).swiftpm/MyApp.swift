//  Operators Challenge
//
//  Copyright © 2024 MobileMakersEdu. All rights reserved.

import SwiftUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
