import SwiftUI

struct ContentView: View {
    let appName = "Repeat After Me"
    @State private var enteredName = ""
    @State var buttonPressed = true
    var body: some View {
        NavigationStack {
            VStack {
                TextField("Entered Name", text: $enteredName)
                    .textFieldStyle(.roundedBorder)
                    .padding()
                    //.background(.blue)
                    .multilineTextAlignment(.center)
                Spacer()
                Text("Hello \(enteredName)")
                    .font(.title)
                 Spacer()
                Button("Change Background") {
                    buttonPressed.toggle()
                }
                .frame(width: 200, height: 50, alignment: .center)
                .background(.black)
                .foregroundColor(.white)
                .padding(.all)
                //Spacer()
               
            }
            .navigationTitle(appName)
            .background(buttonPressed ? .red: .blue)
        }
    }
}
