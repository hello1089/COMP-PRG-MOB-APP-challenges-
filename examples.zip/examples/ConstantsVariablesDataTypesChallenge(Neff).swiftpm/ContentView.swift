//  ConstantsVariablesDataTypes Challenge
//Aidan Neff
//October 15, 2024
//  Copyright © 2024 MobileMakersEdu. All rights reserved.



import SwiftUI

struct ContentView: View {
    
    //MARK: MVP
    @State var showMVP = false
    let firstName:String = "Aidan"
    
    
    var body: some View {
        
        //MARK: Stretch #1
        let lastName:String = "Neff"
        let greeting:String = "Hello Mr \(lastName)."
        
        
        
        //MARK: Stretch #2
        let nameOne:String = "Brady"
        let nameTwo:String = "Isaac"
        let nameThree:String = "August"
        let nameFour:String = "Ninep"
        let teamOne:String = "\(nameOne), \(nameTwo)"
        let teamTwo:String = "\(nameThree), \(nameFour)"
        
        
        
        //MARK: Stretch #3
        let highScoreOne:Int = 50
        let highScoreTwo:Int = 43
        let highScoreThree:Int = 34
        let highScoreFour:Int = 17
        let teamHighScoreOne:String = " \(nameOne) \(highScoreOne) & \(nameTwo) \(highScoreTwo)"
        let teamHighScoreTwo:String = "\(nameThree) \(highScoreThree) & \(nameFour) \(highScoreFour)"
        
        
        VStack {
            VStack {
                Group {
                    Divider()
                    Text("Constants, Variables\nData Types Challenge")
                        .frame(maxWidth: .infinity, alignment: .center)
                        .font(.title)
                    Divider()
                }
                //TODO: MVP, Uncomment the line below
                Button("MVP") { showMVP.toggle() }.alert("Your Name is \(firstName)", isPresented: $showMVP){}.font(.largeTitle).foregroundColor(.primary)
                
                Spacer()
                
                Text("Stretch 1")
                    .font(.largeTitle)
                    .underline()
                
                //TODO: Stretch #1, Uncomment the line below
                Text(greeting)
                
                Spacer()
            }
            VStack {
                
                Text("Stretch 2")
                    .font(.largeTitle)
                    .underline()
                
                //TODO: Stretch #2, Uncomment the line below
                Text("Team 1: \(teamOne)\nTeam 2: \(teamTwo)")
                
                
                Spacer()
                Text("Stretch 3")
                    .font(.largeTitle)
                    .underline()
                
                //TODO: Stretch #3, Uncomment the line below
                Text("\(teamHighScoreOne)\n\(teamHighScoreTwo)")
                
                Spacer()
            }
            
            Group {
                Spacer()
                Image("MobileMakersEdu")
                    .resizable()
                    .frame(maxWidth: .infinity)
                    .scaledToFit()
            }
        }
        .padding()
    }
}
