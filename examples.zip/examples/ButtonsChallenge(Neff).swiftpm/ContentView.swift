//  Buttons Challenge
//
//  Copyright © 2024 MobileMakersEdu. All rights reserved.

import SwiftUI

struct ContentView: View {
    
    @State var lightOnOrOff = true //this helped me do stretch #4
    @State var changeBackground: Bool = true
    @State var counter: Int = 0
    @State var lightBulbStatus: String = "On"
    @State var showAlert = false
    
    var body: some View {
        VStack(spacing: 40) {
            
            Group {
                Divider()
                Text("Buttons Challenge")
                    .frame(maxWidth: .infinity, alignment: .center)
                    .font(.title)
                Divider()
            }
            
            //MARK: MVP
            HStack {
                VStack {
                    HStack {
                        Button("1") {
                            print("Button #1 Was Pressed")
                        }
                        .font(.system(.largeTitle))
                        .frame(width: 100, height: 100, alignment: .center)
                        .background(.red)
                        .foregroundColor(.white)
                        ////
                        Button("2") {
                            print("Button #2 Was Pressed")
                        }
                        .font(.system(.largeTitle))
                        .frame(width: 100, height: 100, alignment: .center)
                        .background(.red)
                        .foregroundColor(.white)
                    }
                       
                    }
                }
            
            
            
            
            
            //MARK: Stretch #1
            Button("Change Background") {
                changeBackground.toggle()
                print("Changed Background")
            }
            .frame(width:100,height: 50)
            .background(RoundedRectangle(cornerRadius: 10).fill(.blue))
            .foregroundColor(.white)
                       
            
            
            
            //MARK: Stretch #2
            
            Button("\(counter)") {
                counter += 1
            }
            .background(Capsule().fill(.gray)
                .frame(width:25, height: 20))
            
            
            
            
            
            //MARK: Stretch #3
            
            VStack {
                Button("", systemImage: "key") {
                    showAlert.toggle()
                }
                .frame(alignment: .trailing)
                .alert("Stretch #3 Complete", isPresented:$showAlert) {
                    Button("OK") {
                        showAlert.toggle()
                    }
                }       
                .frame(width: 20, height: 20, alignment: .center)
                .foregroundColor(.green)
                .background(Circle().fill(.white), alignment: .center)
                .shadow(color: .black, radius: 20)
                
            }
            
            
            
            
            //MARK: Stretch #4
            HStack {
                Button("", systemImage: "lightbulb.fill") {
                    lightBulbStatus = lightBulbStatus == "on" ? "off" :"on"
                    if lightBulbStatus == "on" {
                        lightOnOrOff = true
                    } else {
                        lightOnOrOff = false
                    }
                }
                .foregroundColor(lightOnOrOff ? .yellow: .black)
                Text(lightOnOrOff ? "Light bulb is on.": "Light bulb is off.")
            }       
            //
            //
            //Double tap the light bulb the first time you want to turn
            // it off!!!!!!!!!!
            //
            //Could probably use more if statements and a variable
            //with "Int = 0" and a counting thing to fix that, but I
            //ran out of time in class
            //
            Group {
                
                Image("MobileMakersEduNB")
                    .resizable()
                    .frame(maxWidth: .infinity)
                    .scaledToFit()
                    
            }
            
            
        }
        
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding()
        .background(changeBackground ? .white : .black)
    }
}

