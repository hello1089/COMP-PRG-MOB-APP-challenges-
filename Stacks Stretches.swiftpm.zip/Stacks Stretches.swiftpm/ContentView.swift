import SwiftUI

struct ContentView: View {
    var body: some View {
        HStack {
            VStack {
                ZStack{  
                    Rectangle()
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .background(Color.black)
                    HStack {
                        VStack(alignment: .trailing) {
                        HStack(alignment: .top) {
                            Text("0")
                                .font(.system(size: 100))
                                .frame(width: 100, height: 100, alignment: .topTrailing)
                                .foregroundColor(.white)
                        }
                            
                            
                            
                            
                            
                            
                            
                        }
                        Text("AC")
                            .background(Circle().fill(Color.gray))
                    }
                }
            }
        }
    }
}
