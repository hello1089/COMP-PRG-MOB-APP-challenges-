/*
 Aidan Neff
 
 Shapes Challenge

Thursday, September 5
*/

import SwiftUI

struct ContentView: View {
    var body: some View {
    //MVP SECTION
        Circle()
            .size(width: 100, height: 100)
            .background(.blue)
        Rectangle()
            .trim(from: 0.0, to: 0.75)
            .foregroundColor(.green)
        Ellipse()
            .stroke(.orange, lineWidth: 5)
            .background(.brown)
        Capsule()
            .frame(width: 300 , height: 100)
            .foregroundColor(.cyan)
        RoundedRectangle(cornerRadius: 10)
            .frame(width: 200 , height: 100)
            .foregroundColor(.red)
    }
}
