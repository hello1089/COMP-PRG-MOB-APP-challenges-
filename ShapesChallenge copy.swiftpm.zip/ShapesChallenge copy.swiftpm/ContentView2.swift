import SwiftUI

struct ContentView2: View {
    var body: some View {
        //
        //MVP
        //SECTION
        //
        Rectangle()
            .frame(width: 100 , height: 100 , alignment: .center)
            .foregroundColor(/*@START_MENU_TOKEN@*/.blue/*@END_MENU_TOKEN@*/)
        .frame(width: 150 , height: 150)
        .background(.black)
        
        
    }
}
